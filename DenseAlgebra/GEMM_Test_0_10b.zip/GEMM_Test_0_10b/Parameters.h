#pragma once

#ifndef MATRIX_SIZE_M
#define MATRIX_SIZE_M 1024
#endif

#ifndef MATRIX_SIZE_N
#define MATRIX_SIZE_N 2048
#endif

#ifndef MATRIX_SIZE_K
#define MATRIX_SIZE_K 4092
#endif

#ifndef BLOCK_SIZE
#define BLOCK_SIZE 64
#endif